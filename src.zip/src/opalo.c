#include "opalo.h"
#include "mina.h"
#include "data.h"

static uint32_t hash32(uint32_t x) {
    x ^= x >> 16;
    x *= 0x7feb352d;
    x ^= x >> 15;
    x *= 0x846ca68b;
    x ^= x >> 16;
    return x;
}

// ----------------------------------------------------
// BONUS REGIONAL
// ----------------------------------------------------

void aplicar_bonus_region(Opalo* o, Chunk* c) {

    switch (ciudad_actual_idx) {

        // VALLE CENIZA
        case 0:

            if ((o->seed % 100) < 40) {
                o->tipo = OPALO_FUEGO;
            }

            o->brillo += 2;

            break;

        // COSTA ROSA
        case 1:

            if (o->tipo == OPALO_BLANCO) {
                o->pureza += 10;
            }

            break;

        // LLANURA CRISTAL
        case 2:

            if (o->tipo == OPALO_CRISTAL) {
                o->saturacion += 4;
            }

            break;
    }

    if (o->pureza > 100)
        o->pureza = 100;
}

// ----------------------------------------------------
// QUILATES
// ----------------------------------------------------


static uint16_t calcular_quilates_exacto(uint32_t h, int bonus) {

    uint32_t r = h % 1000000;

    if (bonus > 0) {
        r = (r * (100 - bonus)) / 100;
    }

    if (r < 300000) return 1 + (h % 5);
    if (r < 500000) return 5 + (h % 6);
    if (r < 600000) return 10 + (h % 16);
    if (r < 650000) return 25 + (h % 26);
    if (r < 675000) return 50 + (h % 51);
    if (r < 685000) return 100 + (h % 11);

    return 111 + (uint16_t)(((r - 685000) * 114) / 315000);
}

// ----------------------------------------------------
// OPALO
// ----------------------------------------------------

void generar_opalo(Opalo* o, uint32_t seed) {

    uint32_t h = hash32(seed);

    o->seed = seed;

    o->tipo   = h & 3;
    o->patron = (h >> 2) & 3;

    o->brillo       = 16 + (((h >> 4)  & 15) * ((h >> 4)  & 15) / 15);
    o->saturacion   = 16 + (((h >> 8)  & 15) * ((h >> 8)  & 15) / 15);
    o->iridiscencia = 16 + (((h >> 13) & 15) * ((h >> 13) & 15) / 15);

    // PUREZA
    // distribución sesgada: muchos medios, pocos perfectos

    {
        uint32_t p = (h >> 20) & 1023;

        if (p < 500)
            o->pureza = 40 + (p % 20);
        else if (p < 850)
            o->pureza = 60 + (p % 25);
        else if (p < 980)
            o->pureza = 85 + (p % 10);
        else
            o->pureza = 95 + (p % 6);
    }

    o->color_offset = (h >> 17) & 255;

    o->quilates = 0;
}


// ----------------------------------------------------
// CHUNK
// ----------------------------------------------------

void generar_chunk(Chunk* c, uint32_t seed) {

    uint32_t h = hash32(seed ^ 0xDEADBEEF);

    int bonus = mina_obtener_bonus();

    c->seed = seed;

    c->cortado = 0;

    // ------------------------------------------------
    // TAMAÑO EXTERIOR
    // NO siempre coincide con el interior
    // ------------------------------------------------

    {
        uint32_t engaño = (h >> 5) & 15;

        c->tamanyo = 1 + ((h >> 2) & 3);

        // 25% de chunks engañosos
        if (engaño < 4) {

            if (engaño & 1) {
                if (c->tamanyo > 1)
                    c->tamanyo--;
            }
            else {
                if (c->tamanyo < 4)
                    c->tamanyo++;
            }
        }
    }
    
    
    
    // ------------------------------------------------
    // QUILATES
    // ------------------------------------------------

    c->quilates = calcular_quilates_exacto(h, bonus);

    // ------------------------------------------------
    // GRIETAS
    // ------------------------------------------------

    c->grietas = ((h >> 8) & 255) > 120 ? 1 : 0;

    // tipo aproximado
    c->pista = 1 + ((h >> 16) & 3);

    // intensidad
    c->intensidad_grieta = 1 + ((h >> 22) & 3);

    // forma
    c->forma_grieta = (h >> 24) & 3;

    // pureza aproximada
    c->pureza_aprox = 30 + ((h >> 27) & 63);
}




// ----------------------------------------------------
// VALOR
// ----------------------------------------------------

uint32_t calcular_valor_opalo(const Opalo* o) {

    uint32_t base = (uint32_t)o->quilates * o->quilates / 20;

    uint32_t mult_tipo =
        (o->tipo == OPALO_NEGRO)   ? 50 :
        (o->tipo == OPALO_FUEGO)   ? 30 :
        (o->tipo == OPALO_CRISTAL) ? 20 : 10;

    uint32_t b =
        (o->brillo - 16) +
        (o->saturacion - 16) +
        (o->iridiscencia - 16);

    uint32_t factor_belleza = 10 + b;

    uint32_t valor = (base * mult_tipo) / 10;

    valor = (valor * factor_belleza) / 10;

    // PUREZA
    valor = (valor * (50 + o->pureza)) / 100;

    if (o->patron == PATRON_CHAOS)
        valor = (valor * 3) / 2;

    if (valor < 1)
        valor = 1;

    return valor;
}
