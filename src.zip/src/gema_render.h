#ifndef RENDER_LOGICA_H
#define RENDER_LOGICA_H

#include <stdint.h>
#include "gema.h"
#include "opalo.h"

void renderizar_gema_a_buffer(uint8_t *buffer, int w, int h, const Gema *g);
void renderizar_opalo_pro(uint8_t *buffer, int w, int h, const Gema *g);

void renderizar_transicion(uint8_t *buf_sal, uint8_t *buf_ent, int progreso);

// Buffers de animación
uint8_t* get_anim_buf_a(void);
uint8_t* get_anim_buf_b(void);

// Miniaturas
void renderizar_opalo_pequeno(uint8_t* buf, Gema* g);

void renderizar_opalo_pequeno_celda(
    int x,
    int y,
    Gema* g,
    int pal_base,
    int num_colores
);

// Piedra bruta
void renderizar_roca_pequena(
    int x_pos,
    int y_pos,
    const Chunk* c
);

#endif
