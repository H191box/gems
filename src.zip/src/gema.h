#ifndef GEMA_H
#define GEMA_H

#include <stdint.h>
#include "opalo.h" 

/* ------------------------------------------------------------------ */
/* Etapas de evolución                                                */
/* ------------------------------------------------------------------ */
#define ETAPA_BRUTA     0
#define ETAPA_CORTADA   1
#define ETAPA_PULIDA    2

/* ------------------------------------------------------------------ */
/* Máscaras de campo visible                                          */
/* ------------------------------------------------------------------ */
#define CAMPO_TIPO      0x01
#define CAMPO_PATRON    0x02
#define CAMPO_BRILLO    0x04
#define CAMPO_PUREZA    0x08
#define CAMPO_VALOR     0x10

/* ------------------------------------------------------------------ */
/* Identificador nulo                                                 */
/* ------------------------------------------------------------------ */
#define GEMA_ID_NULO    0xFFFFFFFFu

/* ------------------------------------------------------------------ */
/* Estructura principal                                               */
/* ------------------------------------------------------------------ */
typedef struct {
    uint32_t id;
    uint8_t  etapa;
    uint8_t  tipo_real;
    uint8_t  patron_real;
    uint8_t  brillo_real;
    uint8_t  pureza_real;
    uint8_t  iridiscencia;
    uint8_t  saturacion;
    uint8_t  pista_color;
    uint8_t  pista_intensidad;
    uint8_t  pista_patron;
    uint16_t quilates;
    uint32_t seed_visual;
    
    /* Nuevos campos visuales */
    uint8_t  brillo_x;
    uint8_t  brillo_y;
    uint8_t  brillo_tam;
    
    /* Padding para alineación a 32 bits */
    uint8_t  _pad[1];
} Gema;

/* ------------------------------------------------------------------ */
/* API pública                                                        */
/* ------------------------------------------------------------------ */

void crear_gema_desde_chunk(Gema *g, const Chunk *chunk, uint32_t id, uint8_t bioma);
void calcular_atributos_gema(Gema* g, uint32_t seed, uint8_t bioma);
uint32_t gema_calcular_valor(const Gema* g);

void gema_init(Gema *g);
int gema_es_valida(const Gema *g);
int gema_campo_visible(const Gema *g, uint8_t campo);
int gema_evolucionar(Gema *g);
uint32_t gema_valor_real(const Gema *g);
uint32_t gema_valor_estimado(const Gema *g);
int gema_serializar(const Gema *g, uint8_t *buf);
int gema_deserializar(Gema *g, const uint8_t *buf);

#endif /* GEMA_H */
