#include <stdint.h>
#include "save.h"
#include "opalo.h"
#include "data.h"
#include "gema.h"

#define SRAM_BASE ((uint8_t *)0x0E000000)

#define SAVE_MAGIC   "OPAL"
#define SAVE_VERSION 11     /* Incrementado: formato de gema cambió de 20 a 8 bytes */

/* ------------------------------------------------------------------ */
/* TAMAÑO SERIALIZADO                                                  */
/* ------------------------------------------------------------------ */

#define GEMA_SIZE  8        /* seed(4) + quilates(2) + etapa(1) + flags(1) */
#define CHUNK_SIZE sizeof(Chunk)

/* ------------------------------------------------------------------ */
/* OFFSETS SRAM                                                        */
/*                                                                     */
/* Mapa de memoria (SRAM = 64 KB = 0x0000–0xFFFF):                   */
/*                                                                     */
/*   0x0000  Header   (64 bytes reservados)                           */
/*   0x0040  GAL1     32 × 8  =  256 bytes  → hasta 0x013F           */
/*   0x0200  GAL2      9 × 8  =   72 bytes  → hasta 0x0247           */
/*   0x0300  GAL3     32 × 8  =  256 bytes  → hasta 0x03FF           */
/*   0x0500  TALLER   64 × sizeof(Chunk)                              */
/*   0x1000  DINERO   4 bytes                                         */
/*                                                                     */
/* Total gemas: (32+9+32)×8 = 584 bytes. Antes: 73×20 = 1460 bytes. */
/* ------------------------------------------------------------------ */

#define SRAM_HEADER   0x0000
#define SRAM_GAL1     0x0040
#define SRAM_GAL2     0x0200
#define SRAM_GAL3     0x0300
#define SRAM_TALLER   0x0500
#define SRAM_DINERO   0x1000

/* ------------------------------------------------------------------ */
/* SAVE HEADER                                                         */
/*                                                                     */
/* Eliminados respecto a la versión 10:                               */
/*   - next_gema_id  (ya no hay IDs persistentes)                     */
/*   - num_gemas     (era redundante con num_gal)                     */
/* ------------------------------------------------------------------ */

typedef struct {
    char     magic[4];
    uint32_t version;
    uint32_t current_seed;

    uint8_t  dia;
    uint8_t  mes;
    uint8_t  ciudad;
    int8_t   pos_x;
    int8_t   pos_y;

    uint8_t  _pad[3];

    uint32_t num_gal;
    uint32_t num_gal2;
    uint32_t num_gal3;
    uint32_t num_taller;

} __attribute__((packed)) SaveHeader;

/* ------------------------------------------------------------------ */
/* SRAM — acceso byte a byte (requerido en GBA)                       */
/* ------------------------------------------------------------------ */

static void sram_read(void *dst, const void *src, uint32_t size)
{
    volatile const uint8_t *s = (volatile const uint8_t *)src;
    uint8_t *d = (uint8_t *)dst;
    for (uint32_t i = 0; i < size; i++) d[i] = s[i];
}

static void sram_write(void *dst, const void *src, uint32_t size)
{
    volatile uint8_t *d = (volatile uint8_t *)dst;
    const uint8_t *s = (const uint8_t *)src;
    for (uint32_t i = 0; i < size; i++) d[i] = s[i];
}

/* ------------------------------------------------------------------ */
/* HEADER                                                              */
/* ------------------------------------------------------------------ */

static void leer_header(SaveHeader *h)
{
    sram_read(h, SRAM_BASE + SRAM_HEADER, sizeof(SaveHeader));
}

static void escribir_header(const SaveHeader *h)
{
    sram_write(SRAM_BASE + SRAM_HEADER, h, sizeof(SaveHeader));
}

/* ------------------------------------------------------------------ */
/* VALIDACIÓN                                                          */
/* ------------------------------------------------------------------ */

static int save_valido(void)
{
    SaveHeader h;
    sram_read(&h, SRAM_BASE + SRAM_HEADER, sizeof(SaveHeader));

    return h.magic[0] == 'O' && h.magic[1] == 'P' &&
           h.magic[2] == 'A' && h.magic[3] == 'L' &&
           h.version  == SAVE_VERSION;
}

/* ------------------------------------------------------------------ */
/* INIT                                                                */
/* ------------------------------------------------------------------ */

void save_init(void)
{
    static int init = 0;
    if (init) return;
    init = 1;

    if (!save_valido()) {
        SaveHeader h = {0};
        h.magic[0] = 'O'; h.magic[1] = 'P';
        h.magic[2] = 'A'; h.magic[3] = 'L';
        h.version    = SAVE_VERSION;
        h.num_gal    = 0;
        h.num_gal2   = 0;
        h.num_gal3   = 0;
        h.num_taller = 0;
        escribir_header(&h);

        uint32_t dinero = 500;
        sram_write(SRAM_BASE + SRAM_DINERO, &dinero, 4);
    }
}

/* ------------------------------------------------------------------ */
/* SEED                                                                */
/* ------------------------------------------------------------------ */

void guardar_seed(uint32_t seed)
{
    SaveHeader h; leer_header(&h);
    h.current_seed = seed;
    escribir_header(&h);
}

uint32_t cargar_seed(void)
{
    SaveHeader h; leer_header(&h);
    return h.current_seed;
}

/* ------------------------------------------------------------------ */
/* HELPERS INTERNOS — serialización de una gema a/desde SRAM          */
/*                                                                     */
/* No se vuelca la struct directamente: se usan gema_serializar() y   */
/* gema_deserializar() para garantizar el layout de 8 bytes correcto  */
/* independientemente del compilador o la alineación de la struct.    */
/* ------------------------------------------------------------------ */

static void sram_escribir_gema(uint32_t offset, const Gema *g)
{
    uint8_t buf[GEMA_SIZE];
    gema_serializar(g, buf);
    sram_write(SRAM_BASE + offset, buf, GEMA_SIZE);
}

static void sram_leer_gema(Gema *g, uint32_t offset)
{
    uint8_t buf[GEMA_SIZE];
    sram_read(buf, SRAM_BASE + offset, GEMA_SIZE);
    gema_deserializar(g, buf);
}

/* ------------------------------------------------------------------ */
/* TALLER (chunks en bruto)                                           */
/* ------------------------------------------------------------------ */

int cargar_chunks_taller(Chunk *slots)
{
    save_init();
    SaveHeader h; leer_header(&h);

    uint32_t n = h.num_taller;
    if (n > MAX_TALLER) n = 0;

    for (uint32_t i = 0; i < n; i++)
        sram_read(&slots[i],
                  SRAM_BASE + SRAM_TALLER + i * CHUNK_SIZE,
                  CHUNK_SIZE);

    return (int)n;
}

void guardar_chunk_taller(const Chunk *c)
{
    save_init();
    SaveHeader h; leer_header(&h);

    if (h.num_taller >= MAX_TALLER) return;

    sram_write(SRAM_BASE + SRAM_TALLER + h.num_taller * CHUNK_SIZE,
               c, CHUNK_SIZE);

    h.num_taller++;
    escribir_header(&h);
}

void reset_taller(void)
{
    save_init();
    SaveHeader h; leer_header(&h);
    h.num_taller = 0;
    escribir_header(&h);
}

/* ------------------------------------------------------------------ */
/* GALERÍA 1 (inventario principal)                                   */
/* ------------------------------------------------------------------ */

int cargar_gemas(Gema *slots)
{
    save_init();
    SaveHeader h; leer_header(&h);

    for (uint32_t i = 0; i < h.num_gal; i++)
        sram_leer_gema(&slots[i], SRAM_GAL1 + i * GEMA_SIZE);

    return (int)h.num_gal;
}

void guardar_gema(const Gema *g)
{
    save_init();
    SaveHeader h; leer_header(&h);

    if (h.num_gal >= MAX_GALERIA) return;

    sram_escribir_gema(SRAM_GAL1 + h.num_gal * GEMA_SIZE, g);
    h.num_gal++;
    escribir_header(&h);
}

void actualizar_gema_en_sram(int i, const Gema *g)
{
    sram_escribir_gema(SRAM_GAL1 + (uint32_t)i * GEMA_SIZE, g);
}

void decrementar_num_gemas(void)
{
    SaveHeader h; leer_header(&h);
    if (h.num_gal > 0) h.num_gal--;
    escribir_header(&h);
}

/* ------------------------------------------------------------------ */
/* GALERÍA 2 (vitrina fija)                                           */
/* ------------------------------------------------------------------ */

int cargar_gemas_galeria2(Gema *slots)
{
    save_init();
    SaveHeader h; leer_header(&h);

    for (uint32_t i = 0; i < h.num_gal2; i++)
        sram_leer_gema(&slots[i], SRAM_GAL2 + i * GEMA_SIZE);

    return (int)h.num_gal2;
}

void guardar_gema_galeria2(const Gema *g)
{
    save_init();
    SaveHeader h; leer_header(&h);

    if (h.num_gal2 >= MAX_GALERIA2) return;

    sram_escribir_gema(SRAM_GAL2 + h.num_gal2 * GEMA_SIZE, g);
    h.num_gal2++;
    escribir_header(&h);
}

void actualizar_gema_galeria2(int i, const Gema *g)
{
    sram_escribir_gema(SRAM_GAL2 + (uint32_t)i * GEMA_SIZE, g);
}

void decrementar_num_gemas_galeria2(void)
{
    SaveHeader h; leer_header(&h);
    if (h.num_gal2 > 0) h.num_gal2--;
    escribir_header(&h);
}

/* ------------------------------------------------------------------ */
/* GALERÍA 3 (mercado)                                                */
/* ------------------------------------------------------------------ */

int cargar_gemas_galeria3(Gema *slots)
{
    save_init();
    SaveHeader h; leer_header(&h);

    for (uint32_t i = 0; i < h.num_gal3; i++)
        sram_leer_gema(&slots[i], SRAM_GAL3 + i * GEMA_SIZE);

    return (int)h.num_gal3;
}

void guardar_gema_galeria3(const Gema *g)
{
    save_init();
    SaveHeader h; leer_header(&h);

    if (h.num_gal3 >= MAX_GALERIA3) return;

    sram_escribir_gema(SRAM_GAL3 + h.num_gal3 * GEMA_SIZE, g);
    h.num_gal3++;
    escribir_header(&h);
}

void actualizar_gema_galeria3(int i, const Gema *g)
{
    sram_escribir_gema(SRAM_GAL3 + (uint32_t)i * GEMA_SIZE, g);
}

void decrementar_num_gemas_galeria3(void)
{
    SaveHeader h; leer_header(&h);
    if (h.num_gal3 > 0) h.num_gal3--;
    escribir_header(&h);
}

/* ------------------------------------------------------------------ */
/* ECONOMÍA                                                            */
/* ------------------------------------------------------------------ */

uint32_t obtener_dinero(void)
{
    uint32_t d = 0;
    sram_read(&d, SRAM_BASE + SRAM_DINERO, 4);
    return d;
}

void modificar_dinero(int32_t cantidad)
{
    uint32_t d = obtener_dinero();
    int32_t r  = (int32_t)d + cantidad;
    if (r < 0) r = 0;
    sram_write(SRAM_BASE + SRAM_DINERO, &r, 4);
}

/* ------------------------------------------------------------------ */
/* ESTADO MUNDIAL                                                      */
/* ------------------------------------------------------------------ */

void sync_save_world_state(void)
{
    SaveHeader h; leer_header(&h);
    escribir_header(&h);
}
