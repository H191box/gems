#include <stdint.h>
#include "save.h"

#define SRAM_BASE   ((uint8_t*)0x0E000000)
#define SRAM_HEADER 0x00
#define SRAM_NUM    0x08
#define SRAM_SLOTS  0x0C

typedef struct {
    char     magic[4];
    uint32_t seed;
} SaveHeader;

static void sram_read(void* dst, const void* src, uint32_t size) {
    volatile uint8_t* s = (volatile uint8_t*)src;
    uint8_t* d = (uint8_t*)dst;
    for (uint32_t i = 0; i < size; i++) d[i] = s[i];
}

static void sram_write(void* dst, const void* src, uint32_t size) {
    volatile uint8_t* d = (volatile uint8_t*)dst;
    const uint8_t* s = (const uint8_t*)src;
    for (uint32_t i = 0; i < size; i++) d[i] = s[i];
}

static int magic_valido(void) {
    SaveHeader h;
    sram_read(&h, SRAM_BASE + SRAM_HEADER, sizeof(h));
    return h.magic[0]=='P' && h.magic[1]=='L' &&
           h.magic[2]=='S' && h.magic[3]=='M';
}

static void asegurar_header(uint32_t seed) {
    if (!magic_valido()) {
        SaveHeader h = { .magic = {'P','L','S','M'}, .seed = seed };
        sram_write(SRAM_BASE + SRAM_HEADER, &h, sizeof(h));
        uint32_t cero = 0;
        sram_write(SRAM_BASE + SRAM_NUM, &cero, 4);
    }
}

uint32_t cargar_seed(void) {
    if (!magic_valido()) return 1234567;
    SaveHeader h;
    sram_read(&h, SRAM_BASE + SRAM_HEADER, sizeof(h));
    return h.seed;
}

void guardar_seed(uint32_t seed) {
    SaveHeader h = { .magic = {'P','L','S','M'}, .seed = seed };
    sram_write(SRAM_BASE + SRAM_HEADER, &h, sizeof(h));
}

int cargar_capturas(uint32_t* slots) {
    if (!magic_valido()) return 0;
    uint32_t n = 0;
    sram_read(&n, SRAM_BASE + SRAM_NUM, sizeof(n));
    if (n > MAX_CAPTURAS) n = 0;
    for (uint32_t i = 0; i < n; i++)
        sram_read(&slots[i], SRAM_BASE + SRAM_SLOTS + i * 4, 4);
    return (int)n;
}

void guardar_captura(uint32_t seed) {
    asegurar_header(seed);
    uint32_t n = 0;
    sram_read(&n, SRAM_BASE + SRAM_NUM, sizeof(n));
    if (n > MAX_CAPTURAS) n = 0;
    if (n >= MAX_CAPTURAS) return;  // galeria llena, usar sobreescribir_captura
    sram_write(SRAM_BASE + SRAM_SLOTS + n * 4, &seed, 4);
    n++;
    sram_write(SRAM_BASE + SRAM_NUM, &n, 4);
}

// Sobreescribe un slot existente (0-7) con una nueva seed
void sobreescribir_captura(int slot, uint32_t seed) {
    if (slot < 0 || slot >= MAX_CAPTURAS) return;
    asegurar_header(seed);
    sram_write(SRAM_BASE + SRAM_SLOTS + slot * 4, &seed, 4);
    // num_capturas no cambia, el slot ya existia
}
