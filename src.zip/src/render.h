#ifndef RENDER_H
#define RENDER_H

#include <stdint.h>
#include "gema.h"
#include "opalo.h"

// Dentro de src/render.h
uint16_t* get_vram(void);
uint8_t* get_anim_buf_a(void); // <-- AÑADIR ESTO
uint8_t* get_anim_buf_b(void); // <-- AÑADIR ESTO

void generar_paleta(Opalo *o);


// En render.h o gema_render.h
void generar_paleta_rango(Opalo* o, int base, int num_colores);

void volcar_buf_solo_opalo(uint8_t *buf, int mode);
// --- Renderizado de Escena (Flujo Principal) ---
// Esta es la función maestra que deberías usar en galeria.c
void renderizar_escena_completa(const Gema* g, int offset_opalo, int offset_fondo);

// --- Funciones de Composición y VRAM ---
// (Estas son necesarias para los efectos de transición en galeria.c)
void precalcular_fondo(int offset_bg);
void volcar_frame(const uint8_t* buf_opalo, int offset, int offset_bg);

// --- Utilidades de Fondo ---
void dibujar_fondo_texturizado_optimizado(uint16_t* vram, int offset_bg);

// --- UI (Próximamente a mover a ui.c) ---
void draw_ui_sobre_buffer(const char* nombre);

#endif // RENDER_H
