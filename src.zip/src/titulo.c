#include <stdint.h>
#include <gba_video.h>
#include <gba_input.h>
#include <gba_dma.h>
#include "titulo.h"
#include "title.h"
#include "video.h"

#define PAL_BG_MEM  ((volatile uint16_t*)0x05000000)

void titulo_init(void)
{
    DMA3COPY(titlePal, PAL_BG_MEM, 256 | DMA16 | DMA_ENABLE);

    uint16_t *dst = get_vram();
    DMA3COPY(titleBitmap, dst, 9600 | DMA32 | DMA_ENABLE);
    flip();
    fade_in();
}

uint8_t titulo_update(void)
{
    scanKeys();
    return (keysDown() & KEY_START) ? 1 : 0;
}

void titulo_free(void) { }
