#ifndef TITLE_H
#define TITLE_H

#include <gba_types.h>

#define TITLE_WIDTH      240
#define TITLE_HEIGHT     160
/* Índice de paleta reservado para negro puro (interior cueva) */
#define TITLE_BLACK_IDX  255

extern const u16 titlePal[256];
/* Bitmap con texto PULSA START incluido */
extern const u8  titleBitmap[240 * 160];
/* Bitmap con la franja del texto borrada (negro puro) */
extern const u8  titleBitmapClean[240 * 160];

#endif /* TITLE_H */
