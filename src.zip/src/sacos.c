#include "sacos.h"
#include "save.h"
#include "gema.h"

/* Variables externas */
extern uint8_t ciudad_actual_idx;
extern uint8_t dia_actual;
extern uint8_t mes_actual;

const Saco SACOS[4] = {
    {"SACO POBRE",      50,   3, 1},
    {"SACO MINERO",    200,   6, 2},
    {"SACO INDUSTRIAL", 800, 12, 3},
    {"MEGA CARGAMENTO",3000, 24, 4}
};

/* Semilla global */
static uint32_t saco_seed = 0x12345678;
static uint32_t contador_global = 0;

/* --------------------------------------------------------- */
/* Generación de quilates                                    */
/* Unidad: centésimas de quilate                             */
/* 100 = 1.00 ct                                             */
/* --------------------------------------------------------- */
static uint16_t generar_quilates(uint32_t seed, uint8_t tier)
{
    uint16_t base;
    uint16_t rango;

    switch (tier)
    {
        default:
        case 1: /* 0.20 - 1.19 ct */
            base  = 20;
            rango = 100;
            break;

        case 2: /* 0.50 - 2.99 ct */
            base  = 50;
            rango = 250;
            break;

        case 3: /* 1.00 - 7.99 ct */
            base  = 100;
            rango = 700;
            break;

        case 4: /* 2.00 - 19.99 ct */
            base  = 200;
            rango = 1800;
            break;
    }

    uint16_t q = base + (seed % rango);

    /* -------------------------------------------------- */
    /* JACKPOTS                                           */
    /* -------------------------------------------------- */

    uint32_t r = (seed >> 8) % 10000;

    if (r == 0)
    {
        /* 1 entre 10000 */
        q += 20000;      /* +200 ct */
    }
    else if (r < 10)
    {
        /* 9 entre 10000 */
        q += 5000;       /* +50 ct */
    }
    else if (r < 100)
    {
        /* 90 entre 10000 */
        q += 1000;       /* +10 ct */
    }

    return q;
}

/* --------------------------------------------------------- */
/* Compra de saco                                            */
/* --------------------------------------------------------- */

void comprar_saco(int idx)
{
    if (idx < 0 || idx >= 4)
        return;

    const Saco* s = &SACOS[idx];

    if (obtener_dinero() < (int32_t)s->precio)
        return;

    modificar_dinero(-(int32_t)s->precio);

    for (int i = 0; i < s->cantidad_chunks; i++)
    {
        Gema nueva_gema;

        // 1. Aislamos 16 bits de entropía pura para el factor aleatorio visual
        uint16_t rand_part = (uint16_t)((saco_seed + contador_global++ + (i * 0x9E3779B9u)) & 0xFFFFu);

        // Forzamos que no sea 0 absoluto si estamos en la ciudad 0 y día 0 (evita el centinela de vacio)
        if (rand_part == 0 && ciudad_actual_idx == 0 && dia_actual == 0)
            rand_part = 1;

        // 2. Empaquetamos la seed siguiendo las Reglas Fundamentales de gema.c:
        // Bits 31-24: ciudad_id | Bits 23-16: dia | Bits 15-0: entropía
        nueva_gema.seed = ((uint32_t)ciudad_actual_idx << 24)
                        | ((uint32_t)dia_actual        << 16)
                        | (uint32_t)rand_part;

        // 3. Generamos los quilates usando la nueva semilla matemática equilibrada
        nueva_gema.quilates = generar_quilates(nueva_gema.seed, s->tier);

        // 4. Estado inicial de la gema recién sacada del saco
        nueva_gema.etapa = ETAPA_BRUTA;
        nueva_gema.flags = 0;

        guardar_gema(&nueva_gema);
    }

    saco_seed += 0x9E3779B9u;
}
