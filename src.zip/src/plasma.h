#ifndef PLASMA_H
#define PLASMA_H

#include <stdint.h>

// El plasma ya no depende de la estructura, solo recibe los datos que necesita pintar
uint8_t plasma_pixel(int x, int y, uint8_t off, uint8_t brillo, uint8_t saturacion);
uint8_t plasma_pixel_smooth(int x, int y, int off, uint8_t brillo, uint8_t saturacion);
uint8_t pixel_nebula(int x, int y, uint8_t off);

#endif
