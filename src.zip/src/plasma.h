#ifndef PLASMA_H
#define PLASMA_H

#include <stdint.h>
#include "opalo.h"

// ----------------------------------------------------
// PALETA
// ----------------------------------------------------
void generar_paleta(Opalo* o);

// ----------------------------------------------------
// RENDER FULL SCREEN
// ----------------------------------------------------
void renderizar_opalo(Opalo* o);

// ----------------------------------------------------
// CORE PROCEDURAL (IMPORTANTE PARA THUMBNAILS)
// ----------------------------------------------------
uint8_t plasma_pixel(int x, int y, uint8_t off, const Opalo* o);

// ----------------------------------------------------
// EFECTOS UI
// ----------------------------------------------------
void flash_guardado(void);

#endif
