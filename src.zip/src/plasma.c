#include <stdint.h>
#include "gema.h"
#include "plasma.h"

/* ---------------- LUT ---------------- */
static const int16_t sin_lut[64] = { /* ... tus datos ... */ };

static inline int16_t lut_s(int i) { return sin_lut[i & 63]; }
static inline int16_t lut_c(int i) { return sin_lut[(i + 16) & 63]; }

/* ---------------- PIXELS (Privados) ---------------- */
static uint8_t pixel_nebula(int x, int y, uint8_t off) {
    int v = (lut_s((x + off) >> 2) + lut_c((y + off) >> 2) + 128) & 255;
    return (uint8_t)(16 + ((v * 239) >> 8));
}

// Nota: Asegúrate de que estas funciones existan con la firma correcta (int x, int y, uint8_t off)
// Si necesitan campos de Gema, agrégales el parámetro 'const Gema* g'
static uint8_t pixel_venas(int x, int y, uint8_t off) { /* ... */ return 0; }
static uint8_t pixel_mosaico(int x, int y, uint8_t off) { /* ... */ return 0; }
static uint8_t pixel_chaos(int x, int y, uint8_t off) { /* ... */ return 0; }
static uint8_t pixel_harlequin(int x, int y, uint8_t off) { /* ... */ return 0; }

static uint8_t pixel_matrix(int x, int y, uint8_t off, const Gema* g) {
    // Capa base: gris de roca
    uint8_t v_roca = pixel_nebula(x, y, off);
    uint8_t base   = 10 + (v_roca >> 4) % 20;

    // Capa de manchas
    int p1 = (lut_s((x + off + 37) >> 3) + lut_c((y + off + 37) >> 3) + 128) & 255;
    int p2 = (lut_s((x * 2 + y + off) >> 4) + lut_c((y * 2 - x + off) >> 4) + 128) & 255;
    int mancha = (p1 + p2) >> 1;

    // Usamos g->color_offset (ajusta este nombre según tu gema.h)
    int umbral = 80 + (g->color_offset >> 1); 
    if (umbral > 200) umbral = 200;

    if (mancha > umbral) {
        uint8_t p = pixel_nebula(x, y, off + 73);
        int intensidad = mancha - umbral;
        if (intensidad > 120) intensidad = 120;
        
        int mezclado = ((int)base * (120 - intensidad) + (int)p * intensidad) / 120;
        if (mezclado < 16)  mezclado = 16;
        if (mezclado > 254) mezclado = 254;
        return (uint8_t)mezclado;
    }

    return base;
}

/* ---------------- PÚBLICAS ---------------- */

uint8_t plasma_pixel(int x, int y, uint8_t off, const Gema* g) {
    // Asegúrate de que los PATRON_ sean miembros de g->patron
    switch (g->patron) {
        case PATRON_VENAS:     return pixel_venas(x, y, off);
        case PATRON_MOSAICO:   return pixel_mosaico(x, y, off);
        case PATRON_CHAOS:     return pixel_chaos(x, y, off);
        case PATRON_HARLEQUIN: return pixel_harlequin(x, y, off);
        case PATRON_MATRIX:    return pixel_matrix(x, y, off, g);
        default:               return pixel_nebula(x, y, off);
    }
}

uint8_t plasma_pixel_smooth(int x, int y, uint8_t off, const Gema* g) {
    uint8_t c00 = plasma_pixel(x,     y,     off, g);
    uint8_t c10 = plasma_pixel(x + 1, y,     off, g);
    uint8_t c01 = plasma_pixel(x,     y + 1, off, g);
    uint8_t c11 = plasma_pixel(x + 1, y + 1, off, g);

    int avg = ((int)c00 + c10 + c01 + c11) >> 2;

    int rx = (x + y) >> 1;
    int ry = (y - x + 256) >> 1;
    
    uint8_t layer2 = plasma_pixel(rx, ry, off + 37, g);

    int blended = (avg * 6 + (int)layer2 * 4) / 10;
    
    if (blended < 16)  blended = 16;
    if (blended > 254) blended = 254;
    
    return (uint8_t)blended;
}
